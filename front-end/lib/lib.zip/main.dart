import 'dart:io';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:window_manager/window_manager.dart';
import 'views/home/home_view.dart';
import 'package:axi_stack/controllers/projeto_controller.dart';
import 'package:flutter_localizations/flutter_localizations.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  if (Platform.isWindows || Platform.isLinux || Platform.isMacOS) {
    await windowManager.ensureInitialized();

    // Configurações da janela exclusivas para PC
    WindowOptions windowOptions = const WindowOptions(
      size: Size(1366, 768), 
      center: true, 
      backgroundColor: Colors.transparent, 
      skipTaskbar: false,
      titleBarStyle: TitleBarStyle.hidden,
    );

    // Aguarda a janela ficar pronta, mostra e foca nela
    windowManager.waitUntilReadyToShow(windowOptions, () async {
      await windowManager.show();
      await windowManager.focus();
    });
  }

  runApp(
    MultiProvider(providers: [
      ChangeNotifierProvider(create: (context) => ProjetoController()),
    ],

    child: const MaterialApp(
      title: 'AXI Stack',
      debugShowCheckedModeBanner: false,
      localizationsDelegates: [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      
      supportedLocales: [Locale('pt', 'BR')],
      home: HomeView(),
      ),
    ),
  );
}
